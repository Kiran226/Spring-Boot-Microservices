package com.hotel.users.Exception;

public class UserNotFoundException extends Exception{

}
