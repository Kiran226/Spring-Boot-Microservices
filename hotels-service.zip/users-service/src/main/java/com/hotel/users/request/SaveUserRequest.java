package com.hotel.users.request;

public class SaveUserRequest {

}
