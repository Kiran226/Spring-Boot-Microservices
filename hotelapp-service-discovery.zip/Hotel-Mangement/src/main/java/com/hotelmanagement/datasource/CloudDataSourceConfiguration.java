/**
 * @Copyright: ScotiaGlobal Online, ScotiaBank, 2017
 *
 * cloudDataSource.java
 *
 * @author Tech Mahindra
 * @created at 21-Nov-2017
 * @revision history: 
 */
package com.hotelmanagement.datasource;

import javax.sql.DataSource;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * @author KN00460512
 *
 */

	/*@Configuration
	@Profile("cloud")
	public class CloudDataSourceConfiguration {

	  @Bean
	  public Cloud cloud() {
	    return new CloudFactory().getCloud();
	  }

	  @Bean
	  @ConfigurationProperties()
	  public DataSource dataSource() {
	    return cloud().getSingletonServiceConnector(DataSource.class, null);
	  }
	}*/
