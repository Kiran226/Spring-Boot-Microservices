package com.hotel.users.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hotel.users.bean.UserBean;
import com.hotel.users.request.SaveUserRequest;

@RestController
@RequestMapping("/users")
public class UsersController {
    @GetMapping(path="/healthCheck") 
	 public String usersHealthCheck() {
		return "Users Service Instance";
	}
    @PostMapping(path="/user", consumes = "application/json" , produces = "application/json")
    public UserBean saveUser(@RequestBody SaveUserRequest req) {
    	UserBean user = new UserBean();
		return user; 	
    }
}
