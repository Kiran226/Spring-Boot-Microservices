package com.hotelapp.user.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication(scanBasePackages = {"com.hotelapp.user.*"})
@EnableDiscoveryClient
public class HotelappUserServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelappUserServiceApplication.class, args);
	}

}
