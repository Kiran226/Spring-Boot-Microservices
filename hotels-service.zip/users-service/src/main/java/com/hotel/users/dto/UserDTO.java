package com.hotel.users.dto;

import lombok.Data;

@Data
public class UserDTO {

	private String emailId;
	private String firstName;
	private String lastName;
	private String password;
}
