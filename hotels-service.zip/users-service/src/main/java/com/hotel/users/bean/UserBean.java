package com.hotel.users.bean;

import lombok.Data;

@Data
public class UserBean {

	private String emailId;
	private String firstName;
	private String lastName;
	private String password;
}
