package com.hotel.users.service;

import com.hotel.users.bean.UserBean;
import com.hotel.users.dto.UserDTO;

public class UserServiceImpl implements UsersService{

	@Override
	public UserDTO saveUser(UserBean user) {
		UserDTO userto = new UserDTO();
		return userto;
	}

}
